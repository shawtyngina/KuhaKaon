﻿namespace KuhaKaon3
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.headerPNL = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.headerTX = new System.Windows.Forms.Label();
            this.searchPNL = new System.Windows.Forms.Panel();
            this.searchBT = new System.Windows.Forms.Button();
            this.searchTBX = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.welcomeTX = new System.Windows.Forms.Label();
            this.logoPC = new System.Windows.Forms.PictureBox();
            this.buttonsPNL = new System.Windows.Forms.Panel();
            this.registerBT = new System.Windows.Forms.Button();
            this.cartBT = new System.Windows.Forms.Button();
            this.homeBT = new System.Windows.Forms.Button();
            this.FiltersPNL = new System.Windows.Forms.Panel();
            this.filterBT = new System.Windows.Forms.Button();
            this.sortBT = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.categoryBT = new System.Windows.Forms.Button();
            this.dietaryBT = new System.Windows.Forms.Button();
            this.promosBT = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.headerPNL.SuspendLayout();
            this.searchPNL.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logoPC)).BeginInit();
            this.buttonsPNL.SuspendLayout();
            this.FiltersPNL.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // headerPNL
            // 
            this.headerPNL.Controls.Add(this.label2);
            this.headerPNL.Controls.Add(this.headerTX);
            this.headerPNL.Location = new System.Drawing.Point(338, 127);
            this.headerPNL.Name = "headerPNL";
            this.headerPNL.Size = new System.Drawing.Size(894, 71);
            this.headerPNL.TabIndex = 13;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(327, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Lorem ipsum dolor sit amet, consectetur adipiscing elit";
            // 
            // headerTX
            // 
            this.headerTX.AutoSize = true;
            this.headerTX.Location = new System.Drawing.Point(3, 0);
            this.headerTX.Name = "headerTX";
            this.headerTX.Size = new System.Drawing.Size(129, 16);
            this.headerTX.TabIndex = 0;
            this.headerTX.Text = "It\'s Summer Season!";
            // 
            // searchPNL
            // 
            this.searchPNL.Controls.Add(this.searchBT);
            this.searchPNL.Controls.Add(this.searchTBX);
            this.searchPNL.Controls.Add(this.label1);
            this.searchPNL.Controls.Add(this.welcomeTX);
            this.searchPNL.Location = new System.Drawing.Point(27, 127);
            this.searchPNL.Name = "searchPNL";
            this.searchPNL.Size = new System.Drawing.Size(291, 404);
            this.searchPNL.TabIndex = 12;
            // 
            // searchBT
            // 
            this.searchBT.Location = new System.Drawing.Point(20, 201);
            this.searchBT.Name = "searchBT";
            this.searchBT.Size = new System.Drawing.Size(254, 27);
            this.searchBT.TabIndex = 12;
            this.searchBT.Text = "Search";
            this.searchBT.UseVisualStyleBackColor = true;
            // 
            // searchTBX
            // 
            this.searchTBX.Location = new System.Drawing.Point(20, 173);
            this.searchTBX.Name = "searchTBX";
            this.searchTBX.Size = new System.Drawing.Size(254, 22);
            this.searchTBX.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 119);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(257, 16);
            this.label1.TabIndex = 10;
            this.label1.Text = "Where should we deliver your food today?";
            // 
            // welcomeTX
            // 
            this.welcomeTX.AutoSize = true;
            this.welcomeTX.Location = new System.Drawing.Point(17, 103);
            this.welcomeTX.Name = "welcomeTX";
            this.welcomeTX.Size = new System.Drawing.Size(101, 16);
            this.welcomeTX.TabIndex = 9;
            this.welcomeTX.Text = "Welcome back,";
            // 
            // logoPC
            // 
            this.logoPC.Location = new System.Drawing.Point(27, 26);
            this.logoPC.Name = "logoPC";
            this.logoPC.Size = new System.Drawing.Size(145, 73);
            this.logoPC.TabIndex = 11;
            this.logoPC.TabStop = false;
            // 
            // buttonsPNL
            // 
            this.buttonsPNL.Controls.Add(this.registerBT);
            this.buttonsPNL.Controls.Add(this.cartBT);
            this.buttonsPNL.Controls.Add(this.homeBT);
            this.buttonsPNL.Location = new System.Drawing.Point(951, 39);
            this.buttonsPNL.Name = "buttonsPNL";
            this.buttonsPNL.Size = new System.Drawing.Size(281, 60);
            this.buttonsPNL.TabIndex = 10;
            // 
            // registerBT
            // 
            this.registerBT.Location = new System.Drawing.Point(214, 0);
            this.registerBT.Name = "registerBT";
            this.registerBT.Size = new System.Drawing.Size(67, 59);
            this.registerBT.TabIndex = 2;
            this.registerBT.Text = "Register";
            this.registerBT.UseVisualStyleBackColor = true;
            // 
            // cartBT
            // 
            this.cartBT.Location = new System.Drawing.Point(107, 1);
            this.cartBT.Name = "cartBT";
            this.cartBT.Size = new System.Drawing.Size(67, 59);
            this.cartBT.TabIndex = 1;
            this.cartBT.Text = "Cart";
            this.cartBT.UseVisualStyleBackColor = true;
            // 
            // homeBT
            // 
            this.homeBT.Location = new System.Drawing.Point(0, 0);
            this.homeBT.Name = "homeBT";
            this.homeBT.Size = new System.Drawing.Size(67, 59);
            this.homeBT.TabIndex = 0;
            this.homeBT.Text = "Home";
            this.homeBT.UseVisualStyleBackColor = true;
            // 
            // FiltersPNL
            // 
            this.FiltersPNL.Controls.Add(this.promosBT);
            this.FiltersPNL.Controls.Add(this.dietaryBT);
            this.FiltersPNL.Controls.Add(this.categoryBT);
            this.FiltersPNL.Controls.Add(this.button4);
            this.FiltersPNL.Controls.Add(this.button3);
            this.FiltersPNL.Controls.Add(this.button2);
            this.FiltersPNL.Controls.Add(this.sortBT);
            this.FiltersPNL.Location = new System.Drawing.Point(401, 219);
            this.FiltersPNL.Name = "FiltersPNL";
            this.FiltersPNL.Size = new System.Drawing.Size(831, 27);
            this.FiltersPNL.TabIndex = 14;
            // 
            // filterBT
            // 
            this.filterBT.Location = new System.Drawing.Point(338, 219);
            this.filterBT.Name = "filterBT";
            this.filterBT.Size = new System.Drawing.Size(57, 27);
            this.filterBT.TabIndex = 0;
            this.filterBT.Text = "Filters";
            this.filterBT.UseVisualStyleBackColor = true;
            this.filterBT.Click += new System.EventHandler(this.filterBT_Click);
            // 
            // sortBT
            // 
            this.sortBT.Location = new System.Drawing.Point(0, 0);
            this.sortBT.Name = "sortBT";
            this.sortBT.Size = new System.Drawing.Size(198, 27);
            this.sortBT.TabIndex = 0;
            this.sortBT.Text = "Sort by";
            this.sortBT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sortBT.UseVisualStyleBackColor = true;
            this.sortBT.Click += new System.EventHandler(this.sortBT_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(183, 0);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(0, 0);
            this.button2.TabIndex = 1;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(366, 0);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(0, 0);
            this.button3.TabIndex = 2;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(550, 0);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(0, 0);
            this.button4.TabIndex = 3;
            this.button4.Text = "button4";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // categoryBT
            // 
            this.categoryBT.Location = new System.Drawing.Point(211, 0);
            this.categoryBT.Name = "categoryBT";
            this.categoryBT.Size = new System.Drawing.Size(198, 27);
            this.categoryBT.TabIndex = 4;
            this.categoryBT.Text = "Category";
            this.categoryBT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.categoryBT.UseVisualStyleBackColor = true;
            // 
            // dietaryBT
            // 
            this.dietaryBT.Location = new System.Drawing.Point(422, 0);
            this.dietaryBT.Name = "dietaryBT";
            this.dietaryBT.Size = new System.Drawing.Size(198, 27);
            this.dietaryBT.TabIndex = 5;
            this.dietaryBT.Text = "Dietary";
            this.dietaryBT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.dietaryBT.UseVisualStyleBackColor = true;
            // 
            // promosBT
            // 
            this.promosBT.Location = new System.Drawing.Point(633, 0);
            this.promosBT.Name = "promosBT";
            this.promosBT.Size = new System.Drawing.Size(198, 27);
            this.promosBT.TabIndex = 6;
            this.promosBT.Text = "Promos";
            this.promosBT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.promosBT.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Location = new System.Drawing.Point(338, 262);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(894, 301);
            this.panel1.TabIndex = 15;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Location = new System.Drawing.Point(338, 262);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(894, 93);
            this.panel2.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(894, 93);
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(379, 38);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "Advertisement";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(0, 109);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(894, 120);
            this.button1.TabIndex = 0;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(778, 118);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(104, 16);
            this.label8.TabIndex = 19;
            this.label8.Text = "From 30 minutes";
            this.label8.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(370, 188);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(62, 16);
            this.label9.TabIndex = 18;
            this.label9.Text = "Category";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(288, 188);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(62, 16);
            this.label10.TabIndex = 17;
            this.label10.Text = "Category";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(200, 188);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(62, 16);
            this.label11.TabIndex = 16;
            this.label11.Text = "Category";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(118, 188);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(62, 16);
            this.label12.TabIndex = 15;
            this.label12.Text = "Category";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(118, 160);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(112, 16);
            this.label13.TabIndex = 14;
            this.label13.Text = "Restaurant Name";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(118, 132);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(112, 16);
            this.label14.TabIndex = 13;
            this.label14.Text = "Restaurant Name";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(12, 118);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(100, 103);
            this.pictureBox3.TabIndex = 12;
            this.pictureBox3.TabStop = false;
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1262, 673);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.filterBT);
            this.Controls.Add(this.FiltersPNL);
            this.Controls.Add(this.headerPNL);
            this.Controls.Add(this.searchPNL);
            this.Controls.Add(this.logoPC);
            this.Controls.Add(this.buttonsPNL);
            this.MaximumSize = new System.Drawing.Size(1280, 720);
            this.MinimumSize = new System.Drawing.Size(1280, 720);
            this.Name = "Form4";
            this.Text = "Form4";
            this.headerPNL.ResumeLayout(false);
            this.headerPNL.PerformLayout();
            this.searchPNL.ResumeLayout(false);
            this.searchPNL.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logoPC)).EndInit();
            this.buttonsPNL.ResumeLayout(false);
            this.FiltersPNL.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel headerPNL;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label headerTX;
        private System.Windows.Forms.Panel searchPNL;
        private System.Windows.Forms.Button searchBT;
        private System.Windows.Forms.TextBox searchTBX;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label welcomeTX;
        private System.Windows.Forms.PictureBox logoPC;
        private System.Windows.Forms.Panel buttonsPNL;
        private System.Windows.Forms.Button registerBT;
        private System.Windows.Forms.Button cartBT;
        private System.Windows.Forms.Button homeBT;
        private System.Windows.Forms.Panel FiltersPNL;
        private System.Windows.Forms.Button filterBT;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button sortBT;
        private System.Windows.Forms.Button promosBT;
        private System.Windows.Forms.Button dietaryBT;
        private System.Windows.Forms.Button categoryBT;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button button1;
    }
}