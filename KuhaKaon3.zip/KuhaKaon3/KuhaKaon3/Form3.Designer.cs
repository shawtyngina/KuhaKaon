﻿namespace KuhaKaon3
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonsPNL = new System.Windows.Forms.Panel();
            this.registerBT = new System.Windows.Forms.Button();
            this.cartBT = new System.Windows.Forms.Button();
            this.homeBT = new System.Windows.Forms.Button();
            this.logoPC = new System.Windows.Forms.PictureBox();
            this.searchPNL = new System.Windows.Forms.Panel();
            this.welcomeTX = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.searchTBX = new System.Windows.Forms.TextBox();
            this.searchBT = new System.Windows.Forms.Button();
            this.headerPNL = new System.Windows.Forms.Panel();
            this.headerTX = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.scrollingPNL = new System.Windows.Forms.Panel();
            this.categoriesPNL = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button18 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.button10 = new System.Windows.Forms.Button();
            this.buttonsPNL.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logoPC)).BeginInit();
            this.searchPNL.SuspendLayout();
            this.headerPNL.SuspendLayout();
            this.scrollingPNL.SuspendLayout();
            this.categoriesPNL.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonsPNL
            // 
            this.buttonsPNL.Controls.Add(this.registerBT);
            this.buttonsPNL.Controls.Add(this.cartBT);
            this.buttonsPNL.Controls.Add(this.homeBT);
            this.buttonsPNL.Location = new System.Drawing.Point(950, 39);
            this.buttonsPNL.Name = "buttonsPNL";
            this.buttonsPNL.Size = new System.Drawing.Size(281, 61);
            this.buttonsPNL.TabIndex = 4;
            // 
            // registerBT
            // 
            this.registerBT.Location = new System.Drawing.Point(214, 0);
            this.registerBT.Name = "registerBT";
            this.registerBT.Size = new System.Drawing.Size(67, 59);
            this.registerBT.TabIndex = 2;
            this.registerBT.Text = "Register";
            this.registerBT.UseVisualStyleBackColor = true;
            // 
            // cartBT
            // 
            this.cartBT.Location = new System.Drawing.Point(107, 1);
            this.cartBT.Name = "cartBT";
            this.cartBT.Size = new System.Drawing.Size(67, 59);
            this.cartBT.TabIndex = 1;
            this.cartBT.Text = "Cart";
            this.cartBT.UseVisualStyleBackColor = true;
            // 
            // homeBT
            // 
            this.homeBT.Location = new System.Drawing.Point(0, 0);
            this.homeBT.Name = "homeBT";
            this.homeBT.Size = new System.Drawing.Size(67, 59);
            this.homeBT.TabIndex = 0;
            this.homeBT.Text = "Home";
            this.homeBT.UseVisualStyleBackColor = true;
            // 
            // logoPC
            // 
            this.logoPC.Location = new System.Drawing.Point(26, 26);
            this.logoPC.Name = "logoPC";
            this.logoPC.Size = new System.Drawing.Size(145, 74);
            this.logoPC.TabIndex = 7;
            this.logoPC.TabStop = false;
            // 
            // searchPNL
            // 
            this.searchPNL.Controls.Add(this.searchBT);
            this.searchPNL.Controls.Add(this.searchTBX);
            this.searchPNL.Controls.Add(this.label1);
            this.searchPNL.Controls.Add(this.welcomeTX);
            this.searchPNL.Location = new System.Drawing.Point(26, 127);
            this.searchPNL.Name = "searchPNL";
            this.searchPNL.Size = new System.Drawing.Size(291, 405);
            this.searchPNL.TabIndex = 8;
            // 
            // welcomeTX
            // 
            this.welcomeTX.AutoSize = true;
            this.welcomeTX.Location = new System.Drawing.Point(17, 103);
            this.welcomeTX.Name = "welcomeTX";
            this.welcomeTX.Size = new System.Drawing.Size(101, 16);
            this.welcomeTX.TabIndex = 9;
            this.welcomeTX.Text = "Welcome back,";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 119);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(257, 16);
            this.label1.TabIndex = 10;
            this.label1.Text = "Where should we deliver your food today?";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // searchTBX
            // 
            this.searchTBX.Location = new System.Drawing.Point(20, 173);
            this.searchTBX.Name = "searchTBX";
            this.searchTBX.Size = new System.Drawing.Size(254, 22);
            this.searchTBX.TabIndex = 11;
            // 
            // searchBT
            // 
            this.searchBT.Location = new System.Drawing.Point(20, 201);
            this.searchBT.Name = "searchBT";
            this.searchBT.Size = new System.Drawing.Size(254, 27);
            this.searchBT.TabIndex = 12;
            this.searchBT.Text = "Search";
            this.searchBT.UseVisualStyleBackColor = true;
            // 
            // headerPNL
            // 
            this.headerPNL.Controls.Add(this.label2);
            this.headerPNL.Controls.Add(this.headerTX);
            this.headerPNL.Location = new System.Drawing.Point(337, 127);
            this.headerPNL.Name = "headerPNL";
            this.headerPNL.Size = new System.Drawing.Size(894, 72);
            this.headerPNL.TabIndex = 9;
            // 
            // headerTX
            // 
            this.headerTX.AutoSize = true;
            this.headerTX.Location = new System.Drawing.Point(3, 0);
            this.headerTX.Name = "headerTX";
            this.headerTX.Size = new System.Drawing.Size(129, 16);
            this.headerTX.TabIndex = 0;
            this.headerTX.Text = "It\'s Summer Season!";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(327, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Lorem ipsum dolor sit amet, consectetur adipiscing elit";
            // 
            // scrollingPNL
            // 
            this.scrollingPNL.Controls.Add(this.panel1);
            this.scrollingPNL.Controls.Add(this.categoriesPNL);
            this.scrollingPNL.Location = new System.Drawing.Point(337, 284);
            this.scrollingPNL.Name = "scrollingPNL";
            this.scrollingPNL.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.scrollingPNL.Size = new System.Drawing.Size(894, 283);
            this.scrollingPNL.TabIndex = 10;
            // 
            // categoriesPNL
            // 
            this.categoriesPNL.Controls.Add(this.button9);
            this.categoriesPNL.Controls.Add(this.button8);
            this.categoriesPNL.Controls.Add(this.button7);
            this.categoriesPNL.Controls.Add(this.button6);
            this.categoriesPNL.Controls.Add(this.button5);
            this.categoriesPNL.Controls.Add(this.button4);
            this.categoriesPNL.Controls.Add(this.button3);
            this.categoriesPNL.Controls.Add(this.button2);
            this.categoriesPNL.Controls.Add(this.button1);
            this.categoriesPNL.Controls.Add(this.label3);
            this.categoriesPNL.Location = new System.Drawing.Point(0, 1);
            this.categoriesPNL.Name = "categoriesPNL";
            this.categoriesPNL.Size = new System.Drawing.Size(870, 123);
            this.categoriesPNL.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 15);
            this.label3.Name = "label3";
            this.label3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label3.Size = new System.Drawing.Size(177, 16);
            this.label3.TabIndex = 1;
            this.label3.Text = "Find the perfect meal for you!";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(9, 43);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(86, 80);
            this.button1.TabIndex = 2;
            this.button1.Text = "Category";
            this.button1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(101, 43);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(86, 80);
            this.button2.TabIndex = 3;
            this.button2.Text = "Category";
            this.button2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(193, 43);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(86, 80);
            this.button3.TabIndex = 4;
            this.button3.Text = "Category";
            this.button3.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(285, 43);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(86, 80);
            this.button4.TabIndex = 5;
            this.button4.Text = "Category";
            this.button4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(377, 43);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(86, 80);
            this.button5.TabIndex = 6;
            this.button5.Text = "Category";
            this.button5.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(469, 43);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(86, 80);
            this.button6.TabIndex = 7;
            this.button6.Text = "Category";
            this.button6.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(561, 43);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(86, 80);
            this.button7.TabIndex = 8;
            this.button7.Text = "Category";
            this.button7.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(653, 43);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(86, 80);
            this.button8.TabIndex = 9;
            this.button8.Text = "Category";
            this.button8.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(745, 43);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(86, 80);
            this.button9.TabIndex = 10;
            this.button9.Text = "Category";
            this.button9.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button9.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button10);
            this.panel1.Controls.Add(this.button18);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Location = new System.Drawing.Point(0, 142);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(870, 138);
            this.panel1.TabIndex = 1;
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(9, 43);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(410, 80);
            this.button18.TabIndex = 2;
            this.button18.Text = "Category";
            this.button18.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button18.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 15);
            this.label4.Name = "label4";
            this.label4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label4.Size = new System.Drawing.Size(74, 16);
            this.label4.TabIndex = 1;
            this.label4.Text = "Order Now!";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(421, 43);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(410, 80);
            this.button10.TabIndex = 3;
            this.button10.Text = "Category";
            this.button10.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button10.UseVisualStyleBackColor = true;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1262, 673);
            this.Controls.Add(this.scrollingPNL);
            this.Controls.Add(this.headerPNL);
            this.Controls.Add(this.searchPNL);
            this.Controls.Add(this.logoPC);
            this.Controls.Add(this.buttonsPNL);
            this.MaximumSize = new System.Drawing.Size(1280, 720);
            this.MinimumSize = new System.Drawing.Size(1280, 720);
            this.Name = "Form3";
            this.Text = "Form3";
            this.buttonsPNL.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.logoPC)).EndInit();
            this.searchPNL.ResumeLayout(false);
            this.searchPNL.PerformLayout();
            this.headerPNL.ResumeLayout(false);
            this.headerPNL.PerformLayout();
            this.scrollingPNL.ResumeLayout(false);
            this.categoriesPNL.ResumeLayout(false);
            this.categoriesPNL.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel buttonsPNL;
        private System.Windows.Forms.Button registerBT;
        private System.Windows.Forms.Button cartBT;
        private System.Windows.Forms.Button homeBT;
        private System.Windows.Forms.PictureBox logoPC;
        private System.Windows.Forms.Panel searchPNL;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label welcomeTX;
        private System.Windows.Forms.Button searchBT;
        private System.Windows.Forms.TextBox searchTBX;
        private System.Windows.Forms.Panel headerPNL;
        private System.Windows.Forms.Label headerTX;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel scrollingPNL;
        private System.Windows.Forms.Panel categoriesPNL;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button10;
    }
}